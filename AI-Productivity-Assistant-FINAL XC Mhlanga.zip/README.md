# AI-Productivity-Assistant

An AI-powered workplace productivity assistant that automates common office tasks: email generation, meeting summarization, task planning, research assistance, and chatbot interaction.

Built to demonstrate effective AI tool usage, prompt engineering, and responsible AI practices.

### 🚀 Live Demo
Open `index.html` in your browser for the full UI, or run `app.py` for the Python backend.

### ✨ Features

1.  **Email Generation:** Draft professional emails from brief prompts. Tone control (formal, friendly, persuasive).
2.  **Meeting Summarization:** Paste transcripts or notes → Get summary, action items, decisions, and owners.
3.  **Task Planning:** Breaks a goal into SMART tasks, prioritizes with Eisenhower Matrix, and creates a daily schedule.
4.  **Research Assistance:** Structured research briefs with sources, key insights, and counter-arguments.
5.  **Chatbot Interaction:** Context-aware workplace Q&A assistant.

### 🛠️ Tech Stack
- **Frontend:** HTML5, CSS3, JavaScript (Vanilla) - `index.html`
- **Backend (Optional):** Python Flask - `app.py`
- **AI Integration:** OpenAI API / Gemini API / HuggingFace (pluggable) - configured in `config.py`
- **Prompt Engineering:** Library of tested prompts in `prompts.py`

### 📁 Project Structure
```
AI-Productivity-Assistant/
├── index.html          # Main web app - All-in-one functional UI
├── app.py              # Flask backend API (optional deployment)
├── prompts.py          # Prompt engineering library
├── config.py           # AI API configuration
├── requirements.txt
├── README.md
├── .gitignore
└── docs/
    ├── ETHICS.md       # Responsible AI use
    └── PROMPT_GUIDE.md # How prompts were engineered
```

### Getting Started

#### 1. Create Your GitHub Profile
- Go to https://github.com/signup
- Use your personal email
- Add profile photo, bio, and pin this repo

#### 2. Set Up Repository
```bash
git init
git add .
git commit -m "Initial commit: AI Productivity Assistant"
# Create repo on GitHub named AI-Productivity-Assistant
git remote add origin https://github.com/YOUR_USERNAME/AI-Productivity-Assistant.git
git branch -M main
git push -u origin main
```

#### 3. Run Locally

**Option A: Just Frontend (No setup needed)**
Simply open `index.html` in any browser. It works offline with mock AI responses and you can plug in your API key in the UI.

**Option B: Full Stack**
```bash
pip install -r requirements.txt
python app.py
# Visit http://localhost:5000
```

Set your API key in `config.py` or as environment variable:
```
OPENAI_API_KEY=sk-...
```

### 🧠 Prompt Engineering Highlights
See `prompts.py` and `docs/PROMPT_GUIDE.md`. Techniques used:
- Role-based prompting ("You are a senior executive assistant...")
- Chain-of-Thought for task planning
- Few-shot examples for email tone
- Structured output (JSON) for meeting summaries
- Self-critique loop for research

### ⚖️ Responsible & Ethical Use
- No data is stored without consent
- Transparency: AI-generated content is labeled
- Privacy: Meeting transcripts are processed locally first
- Bias check: Prompts tested for neutral tone
See `docs/ETHICS.md` for full statement.

### 📸 Screenshots
Add screenshots of your running app here for your submission.

### Future Improvements
- Integration with Gmail / Google Calendar / Notion API
- Voice-to-text meeting capture
- Team collaboration mode

---
**Author:** [Your Name] | Built for AI Productivity Project 2026

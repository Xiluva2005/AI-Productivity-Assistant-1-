# Responsible AI & Ethics

## Principles Applied
1. **Transparency:** All outputs labeled as AI-assisted
2. **Privacy:** No storage of meeting transcripts, emails on server unless user opts-in
3. **Bias Mitigation:** Prompts tested for gender-neutral, inclusive language
4. **Human-in-the-loop:** User must review before sending any email/task
5. **No Hallucination:** Research module flags unverified sources
6. **Data Minimization:** Only process what user pastes

## How to demonstrate in submission
- Screenshot of AI label in emails
- Note in README about privacy
- Include prompt that checks for bias

## Compliance
This project uses AI tools responsibly for productivity, not to replace human judgment.


# AI-Powered Workplace Productivity Assistant

A practical, ethical AI assistant that automates 5 core workplace tasks:
1.  **Email Generation** - Professional emails from bullet points
2.  **Meeting Summarization** - Summaries, action items, decisions from transcripts
3.  **Task Planning** - Breaks goals into prioritized tasks with timelines
4.  **Research Assistance** - Structured research briefs with sources framework
5.  **Chatbot Interaction** - Context-aware workplace Q&A chatbot

Built with Python, Streamlit, and prompt engineering best practices.

## 🚀 Live Demo Features
This repo includes a fully functional Streamlit app (`app.py`) that you can run locally or deploy to Streamlit Cloud.

## 🛠️ Tech Stack
- **Frontend:** Streamlit
- **AI Models:** OpenAI GPT-4o / Gemini / Any LLM via API (prompt-engineered, model-agnostic)
- **Prompt Engineering Techniques Used:** Role prompting, Few-shot, Chain-of-Thought, Structured Output, Constraints

## 📁 Project Structure
```
AI-Productivity-Assistant/
├── app.py - Main Streamlit Application
├── requirements.txt
├── README.md
├── prompts/
│   ├── email_prompts.json
│   ├── meeting_prompts.json
│   ├── task_prompts.json
│   └── research_prompts.json
├── examples/
│   └── sample_meeting_transcript.txt
└── ETHICS.md
```

## ⚙️ Getting Started

### 1. Create GitHub Repo
1. Go to github.com -> New Repository
2. Name: `AI-Productivity-Assistant`
3. Public, Add README unchecked (we have one)
4. Create and upload these files.

### 2. Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

### 3. Set your API Key (Optional for demo)
The app works in DEMO mode without an API key using templated logic. To use real LLMs:
Set env variable: `OPENAI_API_KEY` or add to Streamlit secrets.

## 🧠 Prompt Engineering Showcase
Each module uses a carefully engineered prompt. See `/prompts` folder.

Example - Email Prompt:
- Role: "You are an executive communication assistant"
- Context + Tone + Constraints
- Few-shot example
- Structured output

## ✅ Responsible & Ethical AI
See `ETHICS.md` - covers bias mitigation, privacy, transparency, human-in-the-loop.

## 🎥 For Submission
Record a 2-min Loom showing:
- Email generation
- Meeting summary from sample transcript
- Task planner

Built for [Your Program Name] - 2026
